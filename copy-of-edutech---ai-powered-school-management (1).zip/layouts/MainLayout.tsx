import React, { useState } from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import { PageName } from '../types';

interface MainLayoutProps {
  children: React.ReactNode;
  activePage: PageName;
  onNavigate: (page: PageName) => void;
  onLogout: () => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, activePage, onNavigate, onLogout }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  return (
    <div className="flex h-screen bg-slate-100 dark:bg-slate-900">
      <Sidebar 
        activePage={activePage} 
        onNavigate={onNavigate} 
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header onLogout={onLogout} toggleSidebar={toggleSidebar} />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 dark:bg-slate-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-200 mb-6">{activePage}</h1>
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default MainLayout;