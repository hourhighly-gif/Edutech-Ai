import React, { useState, useCallback } from 'react';
import { PageName } from './types';
import LandingPage from './screens/LandingPage';
import LoginScreen from './screens/LoginScreen';
import MainLayout from './layouts/MainLayout';

import DashboardScreen from './screens/DashboardScreen';
import SchoolsManagementScreen from './screens/SchoolsManagementScreen';
import UsersManagementScreen from './screens/UsersManagementScreen';
import MessagingScreen from './screens/MessagingScreen';
import RolesManagementScreen from './screens/RolesManagementScreen';
import InstallerLogsScreen from './screens/InstallerLogsScreen';
import SystemSettingsScreen from './screens/SystemSettingsScreen';
import HelpCenterScreen from './screens/HelpCenterScreen';
import { isEqual } from './utils/isEqual'; // Import to ensure it is part of the bundle


type View = 'LANDING' | 'LOGIN' | 'APP';

const App: React.FC = () => {
  const [view, setView] = useState<View>('LANDING');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activePage, setActivePage] = useState<PageName>('Dashboard');

  const handleLogin = useCallback(() => {
    setIsAuthenticated(true);
    setView('APP');
  }, []);

  const handleLogout = useCallback(() => {
    setIsAuthenticated(false);
    setView('LOGIN');
  }, []);

  const handleNavigate = useCallback((page: PageName) => {
    setActivePage(page);
  }, []);

  const handleGoToPortal = useCallback(() => {
    setView('LOGIN');
  }, []);
  
  const handleGoHome = useCallback(() => {
    setView('LANDING');
  }, []);


  const renderActivePage = () => {
    switch (activePage) {
      case 'Dashboard': return <DashboardScreen />;
      case 'Schools Management': return <SchoolsManagementScreen />;
      case 'Users Management': return <UsersManagementScreen />;
      case 'Messaging & Notifications': return <MessagingScreen />;
      case 'Roles & Permissions Management': return <RolesManagementScreen />;
      case 'Installer Logs Management': return <InstallerLogsScreen />;
      case 'System Settings Management': return <SystemSettingsScreen />;
      case 'Help & Documentation Center': return <HelpCenterScreen />;
      default: return <DashboardScreen />;
    }
  };

  const renderContent = () => {
    if (view === 'APP' && isAuthenticated) {
      return (
        <MainLayout
          activePage={activePage}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
        >
          {renderActivePage()}
        </MainLayout>
      );
    } else if (view === 'LOGIN') {
      return <LoginScreen onLogin={handleLogin} onGoHome={handleGoHome} />;
    } else {
      return <LandingPage onGoToPortal={handleGoToPortal} />;
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-900 text-slate-900 dark:text-slate-100 font-sans">
      {renderContent()}
    </div>
  );
};

export default App;