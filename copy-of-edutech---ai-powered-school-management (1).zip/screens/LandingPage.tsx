import React from 'react';
import { GraduationCap, BarChart3, Wand2, ShieldCheck, Server, Key, School } from 'lucide-react';

interface LandingPageProps {
  onGoToPortal: () => void;
}

const FeatureCard: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="bg-white dark:bg-slate-800/50 p-6 rounded-xl shadow-lg text-center transform hover:-translate-y-2 transition-transform duration-300">
        <div className="inline-block p-4 bg-primary-100 dark:bg-primary-900/50 text-primary-600 rounded-full mb-4">
            {icon}
        </div>
        <h3 className="text-xl font-bold mb-2 text-slate-800 dark:text-slate-200">{title}</h3>
        <p className="text-slate-600 dark:text-slate-400">{description}</p>
    </div>
);

const HowItWorksStep: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
    <div className="flex flex-col items-center text-center">
        <div className="p-5 bg-slate-200 dark:bg-slate-700 text-primary-600 dark:text-primary-300 rounded-full mb-4">
            {icon}
        </div>
        <h3 className="text-lg font-semibold mb-1 text-slate-700 dark:text-slate-200">{title}</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400">{description}</p>
    </div>
);

const LandingPage: React.FC<LandingPageProps> = ({ onGoToPortal }) => {
  return (
    <div className="bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <header className="sticky top-0 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm z-30 shadow-sm">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary-500" />
            <span className="text-2xl font-bold text-slate-800 dark:text-slate-200">EduTech</span>
          </div>
          <button
            onClick={onGoToPortal}
            className="bg-primary-600 text-white font-semibold py-2 px-5 rounded-lg hover:bg-primary-700 transition-colors shadow-md hover:shadow-lg"
          >
            Admin Login
          </button>
        </div>
      </header>
      
      {/* Hero Section */}
      <section className="py-20 md:py-32 text-center bg-white dark:bg-slate-800/20">
        <div className="container mx-auto px-6">
          <h1 className="text-4xl md:text-6xl font-extrabold text-slate-800 dark:text-slate-100 leading-tight">
            The Complete AI-Powered <br className="hidden md:block" />
            <span className="text-primary-500">School Management System</span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto">
            EduTech empowers schools with intelligent tools for test generation, student assessment, and data-driven insights, all aligned with the Nigerian curriculum.
          </p>
          <button
            onClick={onGoToPortal}
            className="mt-10 bg-primary-600 text-white font-bold py-4 px-8 rounded-full text-lg hover:bg-primary-700 transition-all duration-300 transform hover:scale-105 shadow-xl"
          >
            Login to Your Admin Portal
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-slate-100 dark:bg-slate-900">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-200">Why Choose EduTech?</h2>
            <p className="mt-2 text-slate-500 dark:text-slate-400">Everything you need to modernize your school's assessment process.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard
              icon={<Wand2 size={28} />}
              title="AI Test Generation"
              description="Create curriculum-aligned tests in minutes. Our AI understands the Nigerian syllabus to generate relevant questions."
            />
            <FeatureCard
              icon={<BarChart3 size={28} />}
              title="Performance Analytics"
              description="Track student and class performance with insightful charts and data on our powerful teacher dashboard."
            />
            <FeatureCard
              icon={<GraduationCap size={28} />}
              title="Curriculum Focused"
              description="Specifically tailored for Nigerian Nursery, Primary, and Secondary schools for perfect educational fit."
            />
            <FeatureCard
              icon={<ShieldCheck size={28} />}
              title="Secure & Reliable"
              description="A secure platform for both test creation and administration, ensuring data integrity and privacy."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-white dark:bg-slate-800/20">
          <div className="container mx-auto px-6">
              <div className="text-center mb-16">
                  <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-200">Get Started in 3 Simple Steps</h2>
                  <p className="mt-2 text-slate-500 dark:text-slate-400">Our platform is designed for easy self-hosting and deployment.</p>
              </div>
              <div className="relative">
                  <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 dark:bg-slate-700 -translate-y-1/2"></div>
                  <div className="relative grid md:grid-cols-3 gap-12">
                      <HowItWorksStep
                          icon={<Server size={32}/>}
                          title="1. Install on Your Server"
                          description="Download and run our simple installer on your school's server infrastructure."
                      />
                      <HowItWorksStep
                          icon={<Key size={32}/>}
                          title="2. Activate License"
                          description="Purchase a license key and activate your instance to unlock all features for your school."
                      />
                      <HowItWorksStep
                          icon={<School size={32}/>}
                          title="3. Manage Your School"
                          description="Onboard teachers and students, and start leveraging AI to enhance your educational process."
                      />
                  </div>
              </div>
          </div>
      </section>


      {/* Footer */}
      <footer className="bg-slate-800 dark:bg-slate-950 text-slate-400">
        <div className="container mx-auto px-6 py-8 text-center">
            <p>&copy; {new Date().getFullYear()} EduTech. All rights reserved.</p>
            <p className="text-sm mt-1">Empowering the next generation of Nigerian students.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
