import React, { useState, useMemo } from 'react';
import { Role, PermissionModule } from '../types';
import { Shield, Plus, Edit, Trash2, CheckSquare, Square, Save, Info } from 'lucide-react';
import AddEditRoleModal from '../components/modals/AddEditRoleModal';
import DeleteConfirmModal from '../components/modals/DeleteConfirmModal';

const ALL_PERMISSIONS: PermissionModule[] = [
    { id: 'module_schools', name: 'Schools Management', permissions: [
        { id: 'schools:view', name: 'View Schools', description: 'Can view the list of schools' },
        { id: 'schools:add', name: 'Add Schools', description: 'Can add new schools to the platform' },
        { id: 'schools:edit', name: 'Edit Schools', description: 'Can edit details of existing schools' },
        { id: 'schools:delete', name: 'Delete Schools', description: 'Can delete schools from the platform' },
        { id: 'schools:toggle_status', name: 'Toggle School Status', description: 'Can activate or deactivate schools' },
    ]},
    { id: 'module_users', name: 'Users Management', permissions: [
        { id: 'users:view', name: 'View Admins', description: 'Can view the list of admin users' },
        { id: 'users:add', name: 'Add Admins', description: 'Can add new admin users' },
        { id: 'users:edit', name: 'Edit Admins', description: 'Can edit details of admin users' },
        { id: 'users:delete', name: 'Delete Admins', description: 'Can delete admin users' },
        { id: 'users:toggle_status', name: 'Toggle Admin Status', description: 'Can activate or deactivate admin users' },
    ]},
    { id: 'module_roles', name: 'Roles & Permissions', permissions: [
        { id: 'roles:view', name: 'View Roles', description: 'Can view roles and their permissions' },
        { id: 'roles:manage', name: 'Manage Roles', description: 'Can add, edit, and delete roles and assign permissions' },
    ]},
];

const mockRoles: Role[] = [
    { id: 'role_super_admin', name: 'Super Admin', description: 'Has all permissions across the platform.', permissions: ALL_PERMISSIONS.flatMap(m => m.permissions.map(p => p.id)), isCoreRole: true },
    { id: 'role_school_admin', name: 'School Admin', description: 'Manages a single school\'s internal operations.', permissions: [], isCoreRole: true },
    { id: 'role_support', name: 'Support Staff', description: 'Can view most data for troubleshooting but cannot make changes.', permissions: ['schools:view', 'users:view', 'roles:view'] },
];

const RolesManagementScreen: React.FC = () => {
    const [roles, setRoles] = useState<Role[]>(mockRoles);
    const [selectedRole, setSelectedRole] = useState<Role | null>(roles[0]);
    const [permissionChanges, setPermissionChanges] = useState<Record<string, boolean>>({});
    
    const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [roleToEdit, setRoleToEdit] = useState<Role | undefined>(undefined);
    const [roleToDelete, setRoleToDelete] = useState<Role | undefined>(undefined);
    
    const hasChanges = Object.keys(permissionChanges).length > 0;

    const handleSelectRole = (role: Role) => {
        if(hasChanges) {
            if(!confirm("You have unsaved changes. Are you sure you want to discard them?")) return;
        }
        setSelectedRole(role);
        setPermissionChanges({});
    };

    const handlePermissionChange = (permId: string) => {
        const currentPermissions = selectedRole ? new Set(selectedRole.permissions) : new Set();
        const isCurrentlySet = currentPermissions.has(permId);
        const originallyHadPerm = isCurrentlySet;

        const isChanging = permissionChanges[permId] === undefined;
        const newChangeValue = isChanging ? !originallyHadPerm : !permissionChanges[permId];

        // If the change reverts to original state, remove it from changes map
        if(newChangeValue === originallyHadPerm) {
            const newChanges = {...permissionChanges};
            delete newChanges[permId];
            setPermissionChanges(newChanges);
        } else {
            setPermissionChanges(prev => ({ ...prev, [permId]: newChangeValue }));
        }
    };
    
    const handleModuleChange = (module: PermissionModule, shouldHaveAll: boolean) => {
        const changes = {...permissionChanges};
        module.permissions.forEach(perm => {
             const originallyHadPerm = selectedRole?.permissions.includes(perm.id) ?? false;
             if (shouldHaveAll !== originallyHadPerm) {
                 changes[perm.id] = shouldHaveAll;
             } else {
                 delete changes[perm.id];
             }
        });
        setPermissionChanges(changes);
    }
    
    const handleSaveChanges = () => {
        if (!selectedRole) return;
        
        const newPermissions = new Set(selectedRole.permissions);
        Object.entries(permissionChanges).forEach(([permId, shouldHave]) => {
            if (shouldHave) {
                newPermissions.add(permId);
            } else {
                newPermissions.delete(permId);
            }
        });

        const updatedRole = { ...selectedRole, permissions: Array.from(newPermissions) };
        setRoles(roles.map(r => r.id === updatedRole.id ? updatedRole : r));
        setSelectedRole(updatedRole);
        setPermissionChanges({});
    };

    const handleOpenAddModal = () => {
        setRoleToEdit(undefined);
        setIsAddEditModalOpen(true);
    };

    const handleOpenEditModal = (role: Role) => {
        setRoleToEdit(role);
        setIsAddEditModalOpen(true);
    };

    const handleOpenDeleteModal = (role: Role) => {
        setRoleToDelete(role);
        setIsDeleteModalOpen(true);
    };

    const handleSaveRole = (roleToSave: Pick<Role, 'name'| 'description'>) => {
        if(roleToEdit) { // Editing
            const updatedRole = { ...roleToEdit, ...roleToSave };
            setRoles(roles.map(r => r.id === updatedRole.id ? updatedRole : r));
            if(selectedRole?.id === updatedRole.id) {
                setSelectedRole(updatedRole);
            }
        } else { // Adding
            const newRole: Role = { ...roleToSave, id: `role_${Date.now()}`, permissions: [] };
            setRoles([...roles, newRole]);
        }
        setIsAddEditModalOpen(false);
    };

    const handleConfirmDelete = () => {
        if(roleToDelete) {
            setRoles(roles.filter(r => r.id !== roleToDelete.id));
            if (selectedRole?.id === roleToDelete.id) {
                setSelectedRole(roles[0] || null);
            }
            setIsDeleteModalOpen(false);
            setRoleToDelete(undefined);
        }
    };


    const currentPermissionsForSelectedRole = useMemo(() => {
        if (!selectedRole) return new Set<string>();
        
        const permissions = new Set(selectedRole.permissions);
        Object.entries(permissionChanges).forEach(([permId, shouldHave]) => {
            if (shouldHave) permissions.add(permId);
            else permissions.delete(permId);
        });
        return permissions;

    }, [selectedRole, permissionChanges]);

    return (
        <div className="flex flex-col md:flex-row gap-6 h-full min-h-[calc(100vh-12rem)]">
            {/* Roles List */}
            <div className="w-full md:w-1/3 lg:w-1/4 bg-white dark:bg-slate-800 rounded-2xl shadow-md p-4 flex flex-col">
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-lg font-semibold text-slate-700 dark:text-slate-300">Roles</h2>
                    <button onClick={handleOpenAddModal} className="p-2 rounded-md bg-primary-100 text-primary-600 hover:bg-primary-200 dark:bg-primary-900/50 dark:text-primary-300 dark:hover:bg-primary-900">
                        <Plus size={18} />
                    </button>
                </div>
                <ul className="space-y-1 overflow-y-auto">
                    {roles.map(role => (
                        <li key={role.id}>
                            <button
                                onClick={() => handleSelectRole(role)}
                                className={`w-full text-left p-3 rounded-lg transition-colors ${selectedRole?.id === role.id ? 'bg-primary-100 dark:bg-primary-900/50' : 'hover:bg-slate-100 dark:hover:bg-slate-700/50'}`}
                            >
                                <div className="flex justify-between items-center">
                                    <div className="flex flex-col">
                                        <span className={`font-semibold ${selectedRole?.id === role.id ? 'text-primary-600 dark:text-primary-300' : 'text-slate-800 dark:text-slate-200'}`}>{role.name}</span>
                                        <span className="text-xs text-slate-500">{role.description}</span>
                                    </div>
                                    {!role.isCoreRole && selectedRole?.id === role.id && (
                                        <div className="flex items-center gap-1">
                                            <button onClick={(e) => { e.stopPropagation(); handleOpenEditModal(role); }} className="p-1.5 rounded text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-600"><Edit size={14}/></button>
                                            <button onClick={(e) => { e.stopPropagation(); handleOpenDeleteModal(role); }} className="p-1.5 rounded text-red-500 hover:bg-red-100 dark:hover:bg-red-900/50"><Trash2 size={14}/></button>
                                        </div>
                                    )}
                                </div>
                            </button>
                        </li>
                    ))}
                </ul>
            </div>

            {/* Permissions Panel */}
            <div className="flex-1 bg-white dark:bg-slate-800 rounded-2xl shadow-md flex flex-col">
                {selectedRole ? (
                    <>
                        <div className="p-6 border-b border-slate-200 dark:border-slate-700">
                           <div className="flex justify-between items-start">
                             <div>
                                <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">Permissions for {selectedRole.name}</h2>
                                <p className="text-slate-500 dark:text-slate-400 mt-1">{selectedRole.description}</p>
                             </div>
                             {hasChanges && (
                                <button onClick={handleSaveChanges} className="flex items-center gap-2 bg-primary-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors shadow-sm">
                                    <Save size={16} /> Save Changes
                                </button>
                             )}
                           </div>
                           {selectedRole.isCoreRole && (
                                <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/50 rounded-lg flex items-center gap-3 text-blue-700 dark:text-blue-300 text-sm">
                                    <Info size={18} />
                                    <span>Permissions for this core role cannot be modified.</span>
                                </div>
                           )}
                        </div>
                        <div className="p-6 space-y-6 overflow-y-auto">
                            {ALL_PERMISSIONS.map(module => {
                                const allInModule = module.permissions.every(p => currentPermissionsForSelectedRole.has(p.id));
                                const someInModule = !allInModule && module.permissions.some(p => currentPermissionsForSelectedRole.has(p.id));

                                return (
                                    <div key={module.id} className="border border-slate-200 dark:border-slate-700 rounded-lg">
                                        <div className="p-4 bg-slate-50 dark:bg-slate-700/50 rounded-t-lg">
                                            <label className="flex items-center gap-3 w-full cursor-pointer">
                                                <input
                                                    type="checkbox"
                                                    checked={allInModule}
                                                    ref={el => { if (el) { el.indeterminate = someInModule; } }}
                                                    onChange={() => handleModuleChange(module, !allInModule)}
                                                    disabled={selectedRole.isCoreRole}
                                                    className="h-5 w-5 rounded text-primary-600 focus:ring-primary-500 disabled:opacity-50"
                                                />
                                                <span className="font-semibold text-slate-800 dark:text-slate-200">{module.name}</span>
                                            </label>
                                        </div>
                                        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            {module.permissions.map(perm => (
                                                <label key={perm.id} className="flex items-start gap-3 w-full cursor-pointer">
                                                    <input
                                                        type="checkbox"
                                                        checked={currentPermissionsForSelectedRole.has(perm.id)}
                                                        onChange={() => handlePermissionChange(perm.id)}
                                                        disabled={selectedRole.isCoreRole}
                                                        className="h-5 w-5 rounded text-primary-600 focus:ring-primary-500 disabled:opacity-50 mt-0.5"
                                                    />
                                                    <div>
                                                        <span className="font-medium text-slate-700 dark:text-slate-300">{perm.name}</span>
                                                        <p className="text-xs text-slate-500">{perm.description}</p>
                                                    </div>
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </>
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 p-6">
                        <Shield size={64} className="text-slate-400 mb-4" />
                        <h2 className="text-xl font-semibold">Select a Role</h2>
                        <p>Choose a role from the left panel to view and manage its permissions.</p>
                    </div>
                )}
            </div>
            
            <AddEditRoleModal
                isOpen={isAddEditModalOpen}
                onClose={() => setIsAddEditModalOpen(false)}
                onSave={handleSaveRole}
                role={roleToEdit}
            />

            <DeleteConfirmModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                itemName={roleToDelete?.name || ''}
                itemType="role"
            />
        </div>
    );
};

export default RolesManagementScreen;