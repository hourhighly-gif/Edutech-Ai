import React, { useState, useMemo, useEffect } from 'react';
import { School, SchoolStatus, NigerianState, NigerianStates } from '../types';
import { Building2, Search, Plus, Edit, Users } from 'lucide-react';
import AddEditSchoolModal from '../components/modals/AddEditSchoolModal';
import DeleteConfirmModal from '../components/modals/DeleteConfirmModal';
import ActionMenu from '../components/ActionMenu';

const mockSchools: School[] = [
  { id: 'SCH-001', name: 'King\'s College', principal: 'Mr. Andrew Ali', email: 'principal@kingscollege.edu.ng', phone: '08012345678', address: '3, Tafawa Balewa Square', lga: 'Lagos Island', state: 'Lagos', status: 'Active', licenseKey: 'KCL-LGS-A1B2-C3D4', studentCount: 1500, teacherCount: 75, logoUrl: `https://avatar.vercel.sh/kings.svg?text=KC` },
  { id: 'SCH-002', name: 'Queen\'s College', principal: 'Dr. (Mrs.) T. O. Adeyemi', email: 'info@queenscollege.edu.ng', phone: '08087654321', address: 'Queen\'s Drive, Yaba', lga: 'Lagos Mainland', state: 'Lagos', status: 'Active', licenseKey: 'QCL-LGS-E5F6-G7H8', studentCount: 1800, teacherCount: 90, logoUrl: `https://avatar.vercel.sh/queens.svg?text=QC` },
  { id: 'SCH-003', name: 'Barewa College', principal: 'Alhaji Mohammed Sani', email: 'contact@barewacollege.edu.ng', phone: '09011223344', address: 'Tudun Wada, Zaria', lga: 'Zaria', state: 'Kaduna', status: 'Inactive', licenseKey: 'BCL-KAD-I9J0-K1L2', studentCount: 1200, teacherCount: 60, logoUrl: `https://avatar.vercel.sh/barewa.svg?text=BC` },
  { id: 'SCH-004', name: 'Federal Govt. College, Ijanikin', principal: 'Mrs. A. A. Abolaji', email: 'info@fgcl.edu.ng', phone: '07055667788', address: 'Lagos-Badagry Expressway', lga: 'Ojo', state: 'Lagos', status: 'Active', licenseKey: 'FGC-IJK-M3N4-O5P6', studentCount: 2000, teacherCount: 100 },
  { id: 'SCH-005', name: 'Loyola Jesuit College', principal: 'Fr. Samson Ugwu', email: 'admin@loyolajesuit.org', phone: '08199887766', address: 'Gidan Mangoro, Abuja', lga: 'AMAC', state: 'FCT - Abuja', status: 'Active', licenseKey: 'LJC-ABJ-Q7R8-S9T0', studentCount: 650, teacherCount: 55, logoUrl: `https://avatar.vercel.sh/loyola.svg?text=LJC` },
];

const StatCard = ({ title, value, icon }: { title: string, value: string, icon: React.ReactNode }) => (
    <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-md flex items-center gap-4">
        <div className="bg-primary-100 dark:bg-primary-900/50 text-primary-500 p-3 rounded-lg">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-200">{value}</p>
        </div>
    </div>
);


const statusColors: Record<SchoolStatus, string> = {
  Active: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
  Inactive: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300',
  'Pending Activation': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
};

const ITEMS_PER_PAGE = 5;

const SchoolsManagementScreen: React.FC = () => {
    const [schools, setSchools] = useState<School[]>(mockSchools);
    const [searchQuery, setSearchQuery] = useState('');
    const [statusFilter, setStatusFilter] = useState<SchoolStatus | 'All'>('All');
    const [stateFilter, setStateFilter] = useState<NigerianState | 'All'>('All');
    const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedSchool, setSelectedSchool] = useState<School | undefined>(undefined);
    const [currentPage, setCurrentPage] = useState(1);

    const filteredSchools = useMemo(() => {
        return schools
          .filter(school => school.name.toLowerCase().includes(searchQuery.toLowerCase()))
          .filter(school => statusFilter === 'All' || school.status === statusFilter)
          .filter(school => stateFilter === 'All' || school.state === stateFilter);
    }, [schools, searchQuery, statusFilter, stateFilter]);

    const paginatedSchools = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return filteredSchools.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredSchools, currentPage]);
    
    const totalPages = Math.ceil(filteredSchools.length / ITEMS_PER_PAGE);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, statusFilter, stateFilter]);

    const handleOpenAddModal = () => {
        setSelectedSchool(undefined);
        setIsAddEditModalOpen(true);
    };

    const handleOpenEditModal = (school: School) => {
        setSelectedSchool(school);
        setIsAddEditModalOpen(true);
    };

    const handleOpenDeleteModal = (school: School) => {
        setSelectedSchool(school);
        setIsDeleteModalOpen(true);
    };
    
    const handleSaveSchool = (schoolToSave: School) => {
        if(selectedSchool) { // Editing
            setSchools(schools.map(s => s.id === schoolToSave.id ? schoolToSave : s));
        } else { // Adding
            const newSchool = { ...schoolToSave, id: `SCH-${String(schools.length + 1).padStart(3, '0')}` };
            setSchools([newSchool, ...schools]);
        }
        setIsAddEditModalOpen(false);
        setSelectedSchool(undefined);
    };

    const handleConfirmDelete = () => {
        if (selectedSchool) {
            setSchools(schools.filter(s => s.id !== selectedSchool.id));
            setIsDeleteModalOpen(false);
            setSelectedSchool(undefined);
        }
    };
    
    const handleToggleStatus = (schoolToToggle: School) => {
        const newStatus = schoolToToggle.status === 'Active' ? 'Inactive' : 'Active';
        setSchools(schools.map(s => s.id === schoolToToggle.id ? {...s, status: newStatus} : s));
    }

    const totalStudents = useMemo(() => schools.reduce((sum, s) => sum + s.studentCount, 0).toLocaleString(), [schools]);
    const totalTeachers = useMemo(() => schools.reduce((sum, s) => sum + s.teacherCount, 0).toLocaleString(), [schools]);
    const activeSchools = useMemo(() => schools.filter(s => s.status === 'Active').length, [schools]);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Schools" value={String(schools.length)} icon={<Building2 size={24}/>} />
                <StatCard title="Active Schools" value={String(activeSchools)} icon={<Building2 size={24} className="text-green-500" />} />
                <StatCard title="Total Students" value={totalStudents} icon={<Users size={24}/>} />
                <StatCard title="Total Teachers" value={totalTeachers} icon={<Users size={24}/>} />
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-2xl shadow-md">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
                    <div className="relative w-full md:flex-1">
                      <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input type="text" placeholder="Search by school name..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 rounded-md py-2.5 pl-10 pr-4 focus:ring-2 focus:ring-primary-500 border-transparent" />
                    </div>
                    <div className="flex items-center gap-2 w-full flex-col sm:flex-row md:w-auto">
                      <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as SchoolStatus | 'All')} className="w-full sm:w-auto bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
                        <option value="All">All Statuses</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending Activation">Pending</option>
                      </select>
                       <select value={stateFilter} onChange={e => setStateFilter(e.target.value as NigerianState | 'All')} className="w-full sm:w-auto bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
                        <option value="All">All States</option>
                        {NigerianStates.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                      <button onClick={handleOpenAddModal} className="flex items-center gap-2 bg-primary-600 text-white font-semibold py-2.5 px-4 rounded-lg hover:bg-primary-700 transition-colors shadow-sm w-full justify-center sm:w-auto">
                        <Plus size={18} />
                        <span>Add School</span>
                      </button>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-500 dark:text-slate-400 responsive-table">
                        <thead className="text-xs text-slate-700 uppercase bg-slate-50 dark:bg-slate-700 dark:text-slate-300">
                            <tr>
                                <th scope="col" className="px-6 py-3">School Info</th>
                                <th scope="col" className="px-6 py-3">Principal</th>
                                <th scope="col" className="px-6 py-3">Location</th>
                                <th scope="col" className="px-6 py-3 text-center">Users</th>
                                <th scope="col" className="px-6 py-3">Status</th>
                                <th scope="col" className="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedSchools.map((school) => (
                                <tr key={school.id} className="bg-white dark:bg-slate-800 border-b dark:border-slate-700">
                                    <td data-label="School Info" className="px-6 py-4 font-medium text-slate-900 dark:text-white whitespace-nowrap">
                                        <div className="flex items-center gap-3">
                                            <img className="w-10 h-10 rounded-full bg-slate-200" src={school.logoUrl || `https://avatar.vercel.sh/${school.id}.svg?text=${school.name.charAt(0)}`} alt={`${school.name} logo`} />
                                            <div>
                                                <div className="font-bold">{school.name}</div>
                                                <div className="text-slate-500 dark:text-slate-400">{school.id}</div>
                                            </div>
                                        </div>
                                    </td>
                                    <td data-label="Principal" className="px-6 py-4">{school.principal}</td>
                                    <td data-label="Location" className="px-6 py-4">{school.lga}, {school.state}</td>
                                    <td data-label="Users" className="px-6 py-4 text-center md:text-center">{school.studentCount} / {school.teacherCount}</td>
                                    <td data-label="Status" className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[school.status]}`}>
                                            {school.status}
                                        </span>
                                    </td>
                                    <td data-label="Actions" className="px-6 py-4 text-center md:text-center responsive-cell-center">
                                         <div className="flex items-center justify-center md:justify-center gap-1">
                                            <button onClick={() => handleOpenEditModal(school)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300"><Edit size={16} /></button>
                                            <ActionMenu 
                                                itemIsActive={school.status === 'Active'}
                                                onDelete={() => handleOpenDeleteModal(school)}
                                                onToggleStatus={() => handleToggleStatus(school)}
                                                toggleActionName='Status'
                                                deleteActionName='Delete School'
                                            />
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {filteredSchools.length > 0 ? (
                    <div className="flex flex-col sm:flex-row items-center justify-between pt-4 gap-4">
                        <span className="text-sm text-slate-500">
                            Showing {paginatedSchools.length} of {filteredSchools.length} schools
                        </span>
                        <div className="flex gap-2">
                             <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Previous</button>
                             <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Next</button>
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-10 text-slate-500">
                      <Building2 size={48} className="mx-auto text-slate-400 mb-4" />
                      <h3 className="text-lg font-semibold">No Schools Found</h3>
                      <p>No schools match your current search and filter criteria.</p>
                    </div>
                )}
            </div>
            
            <AddEditSchoolModal
                isOpen={isAddEditModalOpen}
                onClose={() => setIsAddEditModalOpen(false)}
                onSave={handleSaveSchool}
                school={selectedSchool}
            />
            
            <DeleteConfirmModal 
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                itemName={selectedSchool?.name || ''}
                itemType="school"
            />
        </div>
    );
};

export default SchoolsManagementScreen;