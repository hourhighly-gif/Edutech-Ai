import React, { useState, useMemo, useEffect } from 'react';
import { User, UserRole, UserStatus, School } from '../types';
import { Search, Plus, Edit, Users as UsersIcon } from 'lucide-react';
import AddEditUserModal from '../components/modals/AddEditUserModal';
import DeleteConfirmModal from '../components/modals/DeleteConfirmModal';
import ActionMenu from '../components/ActionMenu';

const mockInitialUsers: User[] = [
  { id: 'USR-001', name: 'Admin User', email: 'admin@edutech.com', role: 'Super Admin', schoolAffiliation: 'Platform-wide', dateAdded: '2023-01-15', status: 'Active', avatar: `https://avatar.vercel.sh/admin.svg?text=AU` },
  { id: 'USR-002', name: 'Andrew Ali', email: 'principal@kingscollege.edu.ng', role: 'School Admin', schoolAffiliation: "King's College", dateAdded: '2023-09-10', status: 'Active', avatar: `https://avatar.vercel.sh/andrew.svg?text=AA` },
  { id: 'USR-003', name: 'T. O. Adeyemi', email: 'info@queenscollege.edu.ng', role: 'School Admin', schoolAffiliation: "Queen's College", dateAdded: '2023-09-11', status: 'Active', avatar: `https://avatar.vercel.sh/adeyemi.svg?text=TA` },
  { id: 'USR-004', name: 'Mohammed Sani', email: 'contact@barewacollege.edu.ng', role: 'School Admin', schoolAffiliation: 'Barewa College', dateAdded: '2023-08-20', status: 'Inactive', avatar: `https://avatar.vercel.sh/mohammed.svg?text=MS` },
  { id: 'USR-005', name: 'Samson Ugwu', email: 'admin@loyolajesuit.org', role: 'School Admin', schoolAffiliation: 'Loyola Jesuit College', dateAdded: '2023-09-14', status: 'Active', avatar: `https://avatar.vercel.sh/samson.svg?text=SU` },
  { id: 'USR-006', name: 'New Super Admin', email: 'super@edutech.com', role: 'Super Admin', schoolAffiliation: 'Platform-wide', dateAdded: '2024-01-20', status: 'Inactive', avatar: `https://avatar.vercel.sh/super.svg?text=SA` },
];

const mockSchools: Pick<School, 'id' | 'name'>[] = [
  { id: 'SCH-001', name: "King's College" },
  { id: 'SCH-002', name: "Queen's College" },
  { id: 'SCH-003', name: 'Barewa College' },
  { id: 'SCH-004', name: 'Federal Govt. College, Ijanikin' },
  { id: 'SCH-005', name: 'Loyola Jesuit College' },
];

const roleColors: Record<UserRole, string> = {
  'Super Admin': 'bg-purple-100 text-purple-800 dark:bg-purple-900/50 dark:text-purple-300',
  'School Admin': 'bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300',
};

const statusColors: Record<UserStatus, string> = {
  Active: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
  Inactive: 'bg-slate-100 text-slate-800 dark:bg-slate-700 dark:text-slate-300',
};

const ITEMS_PER_PAGE = 5;

const UsersManagementScreen: React.FC = () => {
  const [users, setUsers] = useState<User[]>(mockInitialUsers);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<UserRole | 'All'>('All');
  const [statusFilter, setStatusFilter] = useState<UserStatus | 'All'>('All');
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | undefined>(undefined);
  const [currentPage, setCurrentPage] = useState(1);
  
  const filteredUsers = useMemo(() => {
    return users
      .filter(user => 
        user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
      )
      .filter(user => roleFilter === 'All' || user.role === roleFilter)
      .filter(user => statusFilter === 'All' || user.status === statusFilter);
  }, [users, searchQuery, roleFilter, statusFilter]);

  const paginatedUsers = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredUsers.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredUsers, currentPage]);
    
  const totalPages = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, roleFilter, statusFilter]);

  const handleOpenAddModal = () => {
    setSelectedUser(undefined);
    setIsAddEditModalOpen(true);
  };

  const handleOpenEditModal = (user: User) => {
    setSelectedUser(user);
    setIsAddEditModalOpen(true);
  };

  const handleOpenDeleteModal = (user: User) => {
    setSelectedUser(user);
    setIsDeleteModalOpen(true);
  };

  const handleSaveUser = (userToSave: User) => {
    if (selectedUser) { // Editing
      setUsers(users.map(u => u.id === userToSave.id ? userToSave : u));
    } else { // Adding
      const newUser = { ...userToSave, id: `USR-${String(users.length + 1).padStart(3, '0')}` };
      setUsers([newUser, ...users]);
    }
    setIsAddEditModalOpen(false);
    setSelectedUser(undefined);
  };

  const handleConfirmDelete = () => {
    if (selectedUser) {
      setUsers(users.filter(u => u.id !== selectedUser.id));
      setIsDeleteModalOpen(false);
      setSelectedUser(undefined);
    }
  };
    
  const handleToggleStatus = (userToToggle: User) => {
    const newStatus = userToToggle.status === 'Active' ? 'Inactive' : 'Active';
    setUsers(users.map(u => u.id === userToToggle.id ? {...u, status: newStatus} : u));
  }

  return (
    <>
      <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-2xl shadow-md">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
          <div className="relative w-full md:flex-1">
            <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input type="text" placeholder="Search by name or email..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 rounded-md py-2.5 pl-10 pr-4 focus:ring-2 focus:ring-primary-500 border-transparent" />
          </div>
          <div className="flex items-center gap-2 w-full flex-col sm:flex-row md:w-auto">
            <select value={roleFilter} onChange={e => setRoleFilter(e.target.value as UserRole | 'All')} className="w-full sm:w-auto bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
              <option value="All">All Roles</option>
              <option value="Super Admin">Super Admin</option>
              <option value="School Admin">School Admin</option>
            </select>
             <select value={statusFilter} onChange={e => setStatusFilter(e.target.value as UserStatus | 'All')} className="w-full sm:w-auto bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
              <option value="All">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
            <button onClick={handleOpenAddModal} className="flex items-center gap-2 bg-primary-600 text-white font-semibold py-2.5 px-4 rounded-lg hover:bg-primary-700 transition-colors shadow-sm w-full justify-center sm:w-auto">
              <Plus size={18} />
              <span>Add Admin</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-slate-500 dark:text-slate-400 responsive-table">
            <thead className="text-xs text-slate-700 uppercase bg-slate-50 dark:bg-slate-700 dark:text-slate-300">
              <tr>
                <th scope="col" className="px-6 py-3">User Info</th>
                <th scope="col" className="px-6 py-3">Role</th>
                <th scope="col" className="px-6 py-3">School Affiliation</th>
                <th scope="col" className="px-6 py-3">Date Added</th>
                <th scope="col" className="px-6 py-3">Status</th>
                <th scope="col" className="px-6 py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedUsers.map((user) => (
                <tr key={user.id} className="bg-white dark:bg-slate-800 border-b dark:border-slate-700">
                  <td data-label="User Info" className="px-6 py-4 font-medium text-slate-900 dark:text-white whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <img className="w-10 h-10 rounded-full" src={user.avatar} alt={`${user.name} avatar`} />
                      <div>
                        <div className="font-bold">{user.name}</div>
                        <div className="text-slate-500 dark:text-slate-400">{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td data-label="Role" className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${roleColors[user.role]}`}>
                      {user.role}
                    </span>
                  </td>
                  <td data-label="School Affiliation" className="px-6 py-4">{user.schoolAffiliation}</td>
                  <td data-label="Date Added" className="px-6 py-4">{user.dateAdded}</td>
                  <td data-label="Status" className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusColors[user.status]}`}>
                      {user.status}
                    </span>
                  </td>
                  <td data-label="Actions" className="px-6 py-4 text-center md:text-center responsive-cell-center">
                    <div className="flex items-center justify-center md:justify-center gap-1">
                      <button onClick={() => handleOpenEditModal(user)} className="p-2 rounded-md hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300"><Edit size={16} /></button>
                      <ActionMenu 
                          itemIsActive={user.status === 'Active'}
                          onDelete={() => handleOpenDeleteModal(user)}
                          onToggleStatus={() => handleToggleStatus(user)}
                          toggleActionName="Status"
                          deleteActionName="Delete User"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredUsers.length > 0 ? (
          <div className="flex flex-col sm:flex-row items-center justify-between pt-4 gap-4">
              <span className="text-sm text-slate-500">
                  Showing {paginatedUsers.length} of {filteredUsers.length} users
              </span>
              <div className="flex gap-2">
                   <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Previous</button>
                   <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Next</button>
              </div>
          </div>
        ) : (
          <div className="text-center py-10 text-slate-500">
            <UsersIcon size={48} className="mx-auto text-slate-400 mb-4" />
            <h3 className="text-lg font-semibold">No Users Found</h3>
            <p>No admin users match your current search and filter criteria.</p>
          </div>
        )}
      </div>

      <AddEditUserModal
        isOpen={isAddEditModalOpen}
        onClose={() => setIsAddEditModalOpen(false)}
        onSave={handleSaveUser}
        user={selectedUser}
        schools={mockSchools}
      />
      
      <DeleteConfirmModal 
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleConfirmDelete}
        itemName={selectedUser?.name || ''}
        itemType="admin user"
      />
    </>
  );
};

export default UsersManagementScreen;