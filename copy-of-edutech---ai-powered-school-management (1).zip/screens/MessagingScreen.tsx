import React, { useState } from 'react';
import { Phone, Video, MessageSquare, Users, Paperclip, MoreVertical, Search, Check, CheckCheck, PhoneIncoming, PhoneOutgoing, PhoneMissed, Camera, FileText, Image as ImageIcon, Send, ArrowLeft } from 'lucide-react';

const mockConversations = [
  { id: 1, name: 'John Adebayo (Parent)', avatar: `https://avatar.vercel.sh/john.svg?text=JA`, lastMessage: 'Good morning, when is the PTA meeting?', time: '10:42 AM', unread: 2, online: true, typing: false, messages: [
      { sender: 'other', text: 'Hello, I have a question about my child\'s performance.', time: '10:40 AM', status: 'delivered' },
      { sender: 'me', text: 'Good morning, Mr. Adebayo. I can help with that. Which subject are you concerned about?', time: '10:41 AM', status: 'delivered' },
      { sender: 'other', text: 'It\'s regarding his score in Mathematics.', time: '10:41 AM', status: 'delivered' },
      { sender: 'me', text: 'Okay, I am pulling up his records now. One moment.', time: '10:42 AM', status: 'sent' },
  ]},
  { id: 2, name: 'Amina Salihu (Teacher)', avatar: `https://avatar.vercel.sh/amina.svg?text=AS`, lastMessage: 'Please find the attached JSS1 results.', time: '9:15 AM', unread: 0, online: false, typing: false, messages: [] },
  { id: 3, name: 'Principal Thompson', avatar: `https://avatar.vercel.sh/principal.svg?text=PT`, lastMessage: 'Meeting at 2 PM today.', time: 'Yesterday', unread: 0, online: true, typing: true, messages: [] },
  { id: 4, name: 'Mr. David (Teacher)', avatar: `https://avatar.vercel.sh/david.svg?text=MD`, lastMessage: 'Okay, I will check.', time: 'Yesterday', unread: 0, online: false, typing: false, messages: [] },
];

const mockCalls = [
    { id: 1, name: 'John Adebayo (Parent)', type: 'incoming', status: 'answered', time: '11:05 AM', icon: <PhoneIncoming size={20} className="text-green-500"/> },
    { id: 2, name: 'Amina Salihu (Teacher)', type: 'outgoing', status: 'answered', time: 'Yesterday', icon: <PhoneOutgoing size={20} className="text-blue-500"/> },
    { id: 3, name: 'Principal Thompson', type: 'incoming', status: 'missed', time: 'Yesterday', icon: <PhoneMissed size={20} className="text-red-500"/> },
];

const MainSidebar = ({ activeTab, setActiveTab }: { activeTab: string, setActiveTab: (tab: 'chats' | 'calls' | 'contacts') => void }) => (
    <div className="hidden sm:flex w-20 bg-slate-100 dark:bg-slate-900/50 p-4 flex-col items-center gap-6 border-r border-slate-200 dark:border-slate-700">
        <button onClick={() => setActiveTab('chats')} className={`p-3 rounded-xl ${activeTab === 'chats' ? 'bg-primary-500 text-white' : 'text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
            <MessageSquare size={24} />
        </button>
        <button onClick={() => setActiveTab('calls')} className={`p-3 rounded-xl ${activeTab === 'calls' ? 'bg-primary-500 text-white' : 'text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
            <Phone size={24} />
        </button>
         <button onClick={() => setActiveTab('contacts')} className={`p-3 rounded-xl ${activeTab === 'contacts' ? 'bg-primary-500 text-white' : 'text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
            <Users size={24} />
        </button>
    </div>
);

const MessageStatus = ({ status }: { status: 'sent' | 'delivered' | 'read' }) => {
    if (status === 'delivered' || status === 'read') return <CheckCheck size={16} className={status === 'read' ? 'text-blue-500' : 'text-slate-500'} />;
    return <Check size={16} className="text-slate-500" />;
};

const ChatPanel = ({ conversation, onBack }: { conversation: typeof mockConversations[0], onBack: () => void }) => {
    const [isAttachmentMenuOpen, setIsAttachmentMenuOpen] = useState(false);
    return (
        <div className="w-full flex flex-col bg-slate-50 dark:bg-slate-800 h-full">
            {/* Chat Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between bg-white dark:bg-slate-800/50 flex-shrink-0">
                <div className="flex items-center gap-4">
                    <button onClick={onBack} className="sm:hidden p-2 -ml-2 text-slate-500">
                        <ArrowLeft size={20} />
                    </button>
                    <img src={conversation.avatar} alt={conversation.name} className="w-11 h-11 rounded-full" />
                    <div>
                        <h2 className="font-semibold text-lg text-slate-800 dark:text-slate-200">{conversation.name}</h2>
                        <p className={`text-sm ${conversation.online ? 'text-green-500' : 'text-slate-500'}`}>
                            {conversation.typing ? 'typing...' : conversation.online ? 'Online' : 'Offline'}
                        </p>
                    </div>
                </div>
                <div className="flex items-center gap-1 sm:gap-4">
                    <button className="p-2 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full"><Video size={20} /></button>
                    <button className="p-2 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full"><Phone size={20} /></button>
                    <button className="p-2 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full"><MoreVertical size={20} /></button>
                </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
                {conversation.messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`p-3 rounded-lg max-w-lg ${msg.sender === 'me' ? 'bg-primary-500 text-white' : 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200'}`}>
                            <p>{msg.text}</p>
                            <div className="flex justify-end items-center gap-1 mt-1">
                              <span className={`text-xs ${msg.sender === 'me' ? 'text-primary-200' : 'text-slate-400'}`}>{msg.time}</span>
                              {msg.sender === 'me' && <MessageStatus status={msg.status as any} />}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Message Input */}
            <div className="p-4 bg-white dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-700 flex-shrink-0">
                <div className="relative flex items-center">
                     <div className="relative">
                        <button onClick={() => setIsAttachmentMenuOpen(!isAttachmentMenuOpen)} className="absolute left-2 top-1/2 -translate-y-1/2 p-2.5 text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full">
                            <Paperclip size={20} />
                        </button>
                        {isAttachmentMenuOpen && (
                            <div className="absolute bottom-12 left-0 bg-white dark:bg-slate-700 rounded-xl shadow-lg p-2 w-56">
                                <button className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600"><ImageIcon size={20} className="text-blue-500"/> Photo or Video</button>
                                <button className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600"><FileText size={20} className="text-purple-500"/> Document</button>
                                <button className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-600"><Camera size={20} className="text-green-500"/> Use Camera</button>
                            </div>
                        )}
                    </div>
                    <input type="text" placeholder="Type a message..." className="w-full bg-slate-100 dark:bg-slate-700 rounded-full py-3 pl-14 pr-16 focus:ring-primary-500 border-transparent"/>
                    <button className="absolute right-2 bg-primary-500 text-white p-2.5 rounded-full hover:bg-primary-600 transition-transform hover:scale-110">
                        <Send size={20} />
                    </button>
                </div>
            </div>
        </div>
    );
};

const ListPanel = ({ activeTab, onSelectConversation }: { activeTab: string, onSelectConversation: (conv: any) => void }) => (
    <div className="w-full sm:w-1/3 sm:min-w-[320px] sm:max-w-[400px] border-r border-slate-200 dark:border-slate-700 flex flex-col bg-white dark:bg-slate-800/50">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700">
            <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-200 capitalize">{activeTab}</h1>
            <div className="relative mt-4">
                <input type="text" placeholder="Search..." className="w-full bg-slate-100 dark:bg-slate-700 rounded-md py-2 pl-10 pr-4 focus:ring-primary-500 border-transparent" />
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>
        </div>
        <div className="flex-1 overflow-y-auto">
            {activeTab === 'chats' && mockConversations.map(conv => (
                <div key={conv.id} onClick={() => onSelectConversation(conv)} className="flex items-center p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer border-b border-slate-200 dark:border-slate-700">
                    <img src={conv.avatar} alt={conv.name} className="w-12 h-12 rounded-full mr-4" />
                    <div className="flex-1 overflow-hidden">
                        <p className="font-semibold text-slate-800 dark:text-slate-200">{conv.name}</p>
                        <p className="text-sm text-slate-500 truncate">{conv.lastMessage}</p>
                    </div>
                    <div className="text-right ml-2 flex-shrink-0">
                        <p className="text-xs text-slate-400">{conv.time}</p>
                        {conv.unread > 0 && <span className="mt-1 inline-block bg-primary-500 text-white text-xs font-bold rounded-full px-2 py-0.5">{conv.unread}</span>}
                    </div>
                </div>
            ))}
            {activeTab === 'calls' && mockCalls.map(call => (
                <div key={call.id} className="flex items-center p-4 hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer border-b border-slate-200 dark:border-slate-700">
                    <div className="w-12 h-12 rounded-full mr-4 bg-slate-200 dark:bg-slate-700 flex items-center justify-center">{call.icon}</div>
                    <div className="flex-1">
                        <p className={`font-semibold ${call.status === 'missed' ? 'text-red-500' : 'text-slate-800 dark:text-slate-200'}`}>{call.name}</p>
                        <p className="text-sm text-slate-500 capitalize">{call.type}</p>
                    </div>
                    <div className="text-right">
                        <p className="text-xs text-slate-400">{call.time}</p>
                    </div>
                </div>
            ))}
        </div>
    </div>
);


const MessagingScreen: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'chats' | 'calls' | 'contacts'>('chats');
    const [selectedConversation, setSelectedConversation] = useState<typeof mockConversations[0] | null>(null);

    const handleSelectConversation = (conversation: typeof mockConversations[0]) => {
        setSelectedConversation(conversation);
    };

    const handleBack = () => {
        setSelectedConversation(null);
    };

    return (
        <div className="flex h-[calc(100vh-10rem)] bg-white dark:bg-slate-800 rounded-2xl shadow-md overflow-hidden relative">
            {/* Desktop View */}
            <div className="hidden sm:flex w-full h-full">
                <MainSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
                <ListPanel activeTab={activeTab} onSelectConversation={handleSelectConversation} />
                <div className="flex-1">
                    {selectedConversation ? (
                        <ChatPanel conversation={selectedConversation} onBack={() => {}} />
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 dark:text-slate-400">
                            <MessageSquare size={64} />
                            <h2 className="mt-4 text-xl font-semibold">Select a conversation</h2>
                            <p>Choose from your existing conversations to start chatting.</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Mobile View */}
            <div className="sm:hidden w-full h-full">
                {!selectedConversation ? (
                    <ListPanel activeTab={activeTab} onSelectConversation={handleSelectConversation} />
                ) : (
                    <ChatPanel conversation={selectedConversation} onBack={handleBack} />
                )}
            </div>
        </div>
    );
};

export default MessagingScreen;
