import React, { useState } from 'react';
import { GraduationCap, ArrowLeft } from 'lucide-react';

interface LoginScreenProps {
  onLogin: () => void;
  onGoHome: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGoHome }) => {
  const [email, setEmail] = useState('admin@edutech.com');
  const [password, setPassword] = useState('password');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd validate credentials here
    onLogin();
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-slate-100 dark:bg-slate-900 p-4">
      <div className="w-full max-w-md">
        <button onClick={onGoHome} className="absolute top-8 left-8 flex items-center gap-2 text-primary-600 hover:underline">
          <ArrowLeft size={18} />
          Back to Home Page
       </button>
        <div className="text-center mb-8">
            <GraduationCap className="h-16 w-16 text-primary-500 mx-auto" />
            <h1 className="text-3xl font-bold text-slate-800 dark:text-slate-100 mt-4">EduTech Admin Portal</h1>
            <p className="text-slate-500 dark:text-slate-400">Please sign in to continue</p>
        </div>
        <div className="bg-white dark:bg-slate-800 p-8 rounded-2xl shadow-xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
                className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
            <div>
              <label htmlFor="password"className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
                className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-3 focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
             <div className="flex items-center justify-between">
              <a href="#" className="text-sm text-primary-600 hover:underline">
                Forgot your password?
              </a>
            </div>
            <div>
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-bold text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Sign In
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default LoginScreen;
