import React, { useState, useMemo } from 'react';
import { Search, ChevronDown, BookOpen, Building2, Users, Shield, FileTerminal, Settings } from 'lucide-react';

const faqData = [
    {
        question: "How do I add a new school to the platform?",
        answer: "Navigate to the 'Schools Management' page from the main sidebar. Click the blue 'Add School' button in the top right. A modal will appear where you can fill in all the required details for the new school, including its name, principal, location, and logo.",
        category: 'Schools Management'
    },
    {
        question: "What is the difference between a 'Super Admin' and a 'School Admin'?",
        answer: "A 'Super Admin' has platform-wide access and manages all schools, users, and system settings. A 'School Admin' has limited access and can only manage the internal operations (like students, classes, exams) of their own affiliated school.",
        category: 'User Roles'
    },
    {
        question: "How can I change the permissions for a role?",
        answer: "Go to the 'Roles & Permissions Management' page. Select the role you wish to modify from the list on the left. On the right panel, you can check or uncheck the boxes for each permission. Click 'Save Changes' when you are done.",
        category: 'User Roles'
    },
    {
        question: "Where can I find error logs for an installation?",
        answer: "The 'Installer Logs Management' page provides a detailed view of all system events. You can use the search bar and the level filter (e.g., 'ERROR') to find specific log entries related to installation issues or other system failures.",
        category: 'Installer Logs'
    },
    {
        question: "Can I change the platform's main color and logo?",
        answer: "Yes. As a Super Admin, navigate to 'System Settings Management' and go to the 'General' and 'Appearance' tabs. You can upload a new platform logo and choose a new primary color for branding.",
        category: 'System Settings'
    },
    {
        question: "How are school licenses generated and managed?",
        answer: "Licenses can be generated or assigned when adding or editing a school in the 'Schools Management' page. Default license settings, like duration and prefix, can be configured in the 'System Settings Management' page under the 'License' tab.",
        category: 'Schools Management'
    },
];

const categories = [
    { name: 'Getting Started', icon: BookOpen },
    { name: 'Schools Management', icon: Building2 },
    { name: 'User Roles', icon: Shield },
    { name: 'Installer Logs', icon: FileTerminal },
    { name: 'System Settings', icon: Settings },
];

const FaqItem: React.FC<{ question: string; answer: string; isOpen: boolean; onClick: () => void; }> = ({ question, answer, isOpen, onClick }) => {
    return (
        <div className="border-b border-slate-200 dark:border-slate-700">
            <button onClick={onClick} className="w-full flex justify-between items-center text-left p-5 hover:bg-slate-50 dark:hover:bg-slate-700/50">
                <span className="font-semibold text-slate-800 dark:text-slate-200">{question}</span>
                <ChevronDown size={20} className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-96' : 'max-h-0'}`}>
                <div className="p-5 pt-0 text-slate-600 dark:text-slate-400">
                    <p>{answer}</p>
                </div>
            </div>
        </div>
    );
};

const HelpCenterScreen: React.FC = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [openFaq, setOpenFaq] = useState<number | null>(0);

    const filteredFaqs = useMemo(() => {
        if (!searchQuery) {
            return faqData;
        }
        return faqData.filter(faq =>
            faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
            faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }, [searchQuery]);

    const handleToggleFaq = (index: number) => {
        setOpenFaq(openFaq === index ? null : index);
    };

    return (
        <div className="space-y-12">
            {/* Search and Header Section */}
            <div className="text-center bg-white dark:bg-slate-800 p-8 sm:p-12 rounded-2xl shadow-md">
                <h1 className="text-4xl font-bold text-slate-800 dark:text-slate-100">How can we help?</h1>
                <p className="mt-2 text-slate-500 dark:text-slate-400">Find answers, tutorials, and guides for the EduTech platform.</p>
                <div className="relative mt-6 max-w-2xl mx-auto">
                    <input
                        type="text"
                        placeholder="Search for topics or questions..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full bg-slate-100 dark:bg-slate-700 rounded-full py-4 pl-14 pr-6 text-lg focus:ring-2 focus:ring-primary-500 border-transparent"
                    />
                    <Search size={24} className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
            </div>

            {/* Categories Section */}
            <div className="space-y-4">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200">Browse by Topic</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {categories.map((category) => (
                        <div key={category.name} className="flex items-center gap-4 p-5 bg-white dark:bg-slate-800 rounded-xl shadow-md hover:shadow-lg hover:-translate-y-1 transform transition-all cursor-pointer">
                            <div className="bg-primary-100 dark:bg-primary-900/50 p-3 rounded-lg text-primary-600 dark:text-primary-300">
                                <category.icon size={24} />
                            </div>
                            <div>
                                <h3 className="font-semibold text-lg text-slate-800 dark:text-slate-200">{category.name}</h3>
                                <p className="text-sm text-slate-500">{faqData.filter(f => f.category === category.name).length} articles</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* FAQ Section */}
            <div className="space-y-4">
                 <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200">Frequently Asked Questions</h2>
                 <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-md overflow-hidden">
                    {filteredFaqs.length > 0 ? (
                        filteredFaqs.map((faq, index) => (
                            <FaqItem
                                key={index}
                                question={faq.question}
                                answer={faq.answer}
                                isOpen={openFaq === index}
                                onClick={() => handleToggleFaq(index)}
                            />
                        ))
                    ) : (
                        <div className="p-10 text-center text-slate-500">
                            <h3 className="text-lg font-semibold">No Results Found</h3>
                            <p>Your search for "{searchQuery}" did not match any FAQs.</p>
                        </div>
                    )}
                 </div>
            </div>
        </div>
    );
};

export default HelpCenterScreen;