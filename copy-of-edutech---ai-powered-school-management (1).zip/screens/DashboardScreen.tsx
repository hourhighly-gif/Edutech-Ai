import React from 'react';
import { Building2, Users, Wallet, ArrowUpRight, ArrowDownRight, UserPlus, FileText, Bell } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const StatCard = ({ title, value, icon, change, changeType }: { title: string, value: string, icon: React.ReactNode, change: string, changeType: 'increase' | 'decrease' }) => (
    <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md flex justify-between items-center">
        <div>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
            <p className="text-3xl font-bold text-slate-800 dark:text-slate-200 mt-1">{value}</p>
            <div className={`flex items-center mt-2 text-sm ${changeType === 'increase' ? 'text-green-500' : 'text-red-500'}`}>
                {changeType === 'increase' ? <ArrowUpRight size={16} className="mr-1" /> : <ArrowDownRight size={16} className="mr-1" />}
                {change} vs last month
            </div>
        </div>
        <div className="bg-primary-100 dark:bg-primary-900/50 text-primary-500 p-4 rounded-full">
            {icon}
        </div>
    </div>
);

const QuickActionButton = ({ title, icon }: { title: string, icon: React.ReactNode }) => (
    <button className="flex flex-col items-center justify-center gap-2 bg-slate-50 dark:bg-slate-700/50 p-4 rounded-xl hover:bg-primary-100 dark:hover:bg-primary-900/50 hover:text-primary-600 transition-colors w-full">
        {icon}
        <span className="text-sm font-semibold">{title}</span>
    </button>
);

const revenueData = [
  { name: 'Jan', revenue: 40000 }, { name: 'Feb', revenue: 30000 }, { name: 'Mar', revenue: 50000 },
  { name: 'Apr', revenue: 45000 }, { name: 'May', revenue: 60000 }, { name: 'Jun', revenue: 55000 },
];

const schoolsByStateData = [
    { state: 'Lagos', count: 3 },
    { state: 'Kaduna', count: 1 },
    { state: 'FCT', count: 1 },
    { state: 'Oyo', count: 0 },
    { state: 'Rivers', count: 0 },
];

const recentActivities = [
    { icon: <Building2 className="text-green-500" size={20}/>, text: 'New school "Loyola Jesuit College" completed onboarding.', time: '2 hours ago' },
    { icon: <Users className="text-blue-500" size={20}/>, text: 'New admin "Andrew Ali" was added for King\'s College.', time: '1 day ago' },
    { icon: <Wallet className="text-yellow-500" size={20}/>, text: 'License key activated for "Queen\'s College".', time: '2 days ago' },
];


const DashboardScreen: React.FC = () => {
    return (
        <div className="space-y-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Active Schools" value="4" icon={<Building2 size={24}/>} change="+1" changeType="increase" />
                <StatCard title="Total Students" value="5,150" icon={<Users size={24}/>} change="+650" changeType="increase" />
                <StatCard title="Admin Users" value="5" icon={<Users size={24}/>} change="+1" changeType="increase" />
                <StatCard title="Platform Revenue" value="₦1.2M" icon={<Wallet size={24}/>} change="+15%" changeType="increase" />
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md">
                <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mb-4">Quick Actions</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <QuickActionButton title="Add School" icon={<Building2 size={24}/>} />
                    <QuickActionButton title="Add Admin" icon={<UserPlus size={24}/>} />
                    <QuickActionButton title="View Reports" icon={<FileText size={24}/>} />
                    <QuickActionButton title="Send Notification" icon={<Bell size={24}/>} />
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md">
                    <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mb-4">Platform Revenue Overview</h2>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={revenueData}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(100, 116, 139, 0.2)" />
                          <XAxis dataKey="name" stroke="rgb(100 116 139)" fontSize={12} />
                          <YAxis stroke="rgb(100 116 139)" fontSize={12} />
                          <Tooltip contentStyle={{ backgroundColor: 'rgb(30 41 59)', borderColor: 'rgb(51 65 85)' }} formatter={(value: number) => `₦${value.toLocaleString()}`} />
                          <Bar dataKey="revenue" fill="#0891b2" name="Revenue" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
                 <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md">
                    <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mb-4">Schools by State</h2>
                     <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={schoolsByStateData} layout="vertical">
                           <CartesianGrid strokeDasharray="3 3" stroke="rgba(100, 116, 139, 0.2)" />
                           <XAxis type="number" stroke="rgb(100 116 139)" fontSize={12} />
                           <YAxis type="category" dataKey="state" stroke="rgb(100 116 139)" fontSize={12} width={60} />
                           <Tooltip contentStyle={{ backgroundColor: 'rgb(30 41 59)', borderColor: 'rgb(51 65 85)' }}/>
                           <Bar dataKey="count" fill="#0e7490" name="Number of Schools" />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
             <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-md">
                <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300 mb-4">Recent Activity</h2>
                 <ul className="space-y-3">
                    {recentActivities.map((activity, index) => (
                        <li key={index} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 bg-slate-50 dark:bg-slate-700/50 rounded-lg gap-2">
                            <div className="flex items-center gap-3">
                                <div className="bg-slate-200 dark:bg-slate-900/50 p-2 rounded-md flex-shrink-0">{activity.icon}</div>
                                <p className="font-medium text-slate-800 dark:text-slate-200 text-left">{activity.text}</p>
                            </div>
                            <p className="text-sm text-slate-500 whitespace-nowrap self-end sm:self-center">{activity.time}</p>
                        </li>
                    ))}
                 </ul>
            </div>
        </div>
    );
};

export default DashboardScreen;