import React, { useState, useMemo, useEffect } from 'react';
import { SystemSettings } from '../types';
import { Settings, Image as ImageIcon, Palette, Bell, Key, GraduationCap, Upload, Save, XCircle } from 'lucide-react';
import { isEqual } from '../utils/isEqual'; // We'll create this utility

const mockSettings: SystemSettings = {
    general: {
        platformName: 'EduTech',
        platformLogo: `https://avatar.vercel.sh/edutech.svg?text=ET`,
        academicYearStart: '2024-09-01',
        academicYearEnd: '2025-07-15',
    },
    appearance: {
        theme: 'system',
        primaryColor: '#06b6d4', // primary-500
    },
    notifications: {
        senderName: 'EduTech Platform',
        senderEmail: 'noreply@edutech.com',
    },
    integrations: {
        paymentGatewayKey: 'pk_test_************************',
        geminiApiKey: 'AIzaSy*************************',
    },
    license: {
        defaultDurationDays: 365,
        prefix: 'EDT',
    }
};

const colorPalette = [
    { name: 'Teal', color: '#06b6d4' },
    { name: 'Blue', color: '#3b82f6' },
    { name: 'Indigo', color: '#6366f1' },
    { name: 'Purple', color: '#8b5cf6' },
    { name: 'Pink', color: '#ec4899' },
    { name: 'Rose', color: '#f43f5e' },
];

type TabName = 'General' | 'Appearance' | 'Notifications' | 'Integrations' | 'License';

const tabs: { name: TabName, icon: React.ElementType }[] = [
    { name: 'General', icon: Settings },
    { name: 'Appearance', icon: Palette },
    { name: 'Notifications', icon: Bell },
    { name: 'Integrations', icon: Key },
    { name: 'License', icon: GraduationCap },
];

const SystemSettingsScreen: React.FC = () => {
    const [initialSettings, setInitialSettings] = useState<SystemSettings>(JSON.parse(JSON.stringify(mockSettings)));
    const [settings, setSettings] = useState<SystemSettings>(JSON.parse(JSON.stringify(mockSettings)));
    const [activeTab, setActiveTab] = useState<TabName>('General');

    const [logoPreview, setLogoPreview] = useState<string>(settings.general.platformLogo);

    const hasChanges = useMemo(() => !isEqual(initialSettings, settings), [initialSettings, settings]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        const [section, key] = name.split('.');
        setSettings(prev => ({
            ...prev,
            [section]: {
                // @ts-ignore
                ...prev[section],
                [key]: value,
            }
        }));
    };
    
    const handleColorChange = (color: string) => {
        setSettings(prev => ({
            ...prev,
            appearance: {
                ...prev.appearance,
                primaryColor: color,
            }
        }));
    };

    const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                setLogoPreview(result);
                setSettings(prev => ({
                    ...prev,
                    general: { ...prev.general, platformLogo: result }
                }));
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleSaveChanges = () => {
        setInitialSettings(JSON.parse(JSON.stringify(settings)));
        // Here you would typically make an API call to save the settings
        console.log("Settings saved:", settings);
    };

    const handleCancelChanges = () => {
        setSettings(JSON.parse(JSON.stringify(initialSettings)));
        setLogoPreview(initialSettings.general.platformLogo);
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'General': return (
                <div className="space-y-6">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Platform Logo</label>
                        <div className="flex items-center gap-4">
                            <div className="w-20 h-20 rounded-lg bg-slate-100 dark:bg-slate-700 flex items-center justify-center overflow-hidden ring-2 ring-slate-200 dark:ring-slate-600">
                                <img src={logoPreview} alt="Logo Preview" className="w-full h-full object-cover" />
                            </div>
                            <div>
                                <label htmlFor="logo-upload" className="cursor-pointer bg-slate-200 dark:bg-slate-600 text-slate-700 dark:text-slate-200 font-semibold py-2 px-4 rounded-lg hover:bg-slate-300 dark:hover:bg-slate-500 transition-colors shadow-sm flex items-center gap-2">
                                   <Upload size={16}/><span>Upload New Logo</span>
                                </label>
                                <input id="logo-upload" type="file" className="hidden" onChange={handleLogoChange} accept="image/png, image/jpeg"/>
                            </div>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="general.platformName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Platform Name</label>
                        <input type="text" name="general.platformName" id="general.platformName" value={settings.general.platformName} onChange={handleInputChange} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                           <label htmlFor="general.academicYearStart" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Academic Year Start</label>
                           <input type="date" name="general.academicYearStart" id="general.academicYearStart" value={settings.general.academicYearStart} onChange={handleInputChange} className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        </div>
                        <div>
                           <label htmlFor="general.academicYearEnd" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Academic Year End</label>
                           <input type="date" name="general.academicYearEnd" id="general.academicYearEnd" value={settings.general.academicYearEnd} onChange={handleInputChange} className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        </div>
                    </div>
                </div>
            );
            case 'Appearance': return (
                <div className="space-y-6">
                    <div>
                        <label htmlFor="appearance.theme" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Theme</label>
                        <select name="appearance.theme" id="appearance.theme" value={settings.appearance.theme} onChange={handleInputChange} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
                            <option value="light">Light</option>
                            <option value="dark">Dark</option>
                            <option value="system">System Default</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">Primary Color</label>
                        <div className="flex flex-wrap gap-3">
                            {colorPalette.map(c => (
                                <button key={c.name} type="button" onClick={() => handleColorChange(c.color)} className={`w-16 h-16 rounded-lg flex items-center justify-center ring-2 transition-all ${settings.appearance.primaryColor === c.color ? 'ring-offset-2 dark:ring-offset-slate-800 ring-blue-500' : 'ring-transparent hover:ring-slate-300'}`} style={{backgroundColor: c.color}}>
                                </button>
                            ))}
                        </div>
                        <p className="text-xs text-slate-500 mt-2">Example Button: <button className="px-3 py-1 text-white rounded text-sm" style={{backgroundColor: settings.appearance.primaryColor}}>Click Me</button></p>
                    </div>
                </div>
            );
            case 'Notifications': return (
                 <div className="space-y-6">
                     <div>
                        <label htmlFor="notifications.senderName" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Sender Name</label>
                        <input type="text" name="notifications.senderName" id="notifications.senderName" value={settings.notifications.senderName} onChange={handleInputChange} placeholder="EduTech Platform" className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">The name that appears on outgoing system emails.</p>
                    </div>
                    <div>
                        <label htmlFor="notifications.senderEmail" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Sender Email</label>
                        <input type="email" name="notifications.senderEmail" id="notifications.senderEmail" value={settings.notifications.senderEmail} onChange={handleInputChange} placeholder="noreply@edutech.com" className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">The email address used to send notifications.</p>
                    </div>
                </div>
            );
            case 'Integrations': return (
                 <div className="space-y-6">
                     <div>
                        <label htmlFor="integrations.paymentGatewayKey" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Payment Gateway API Key</label>
                        <input type="password" name="integrations.paymentGatewayKey" id="integrations.paymentGatewayKey" value={settings.integrations.paymentGatewayKey} onChange={handleInputChange} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">Enter your API key for services like Paystack or Flutterwave.</p>
                    </div>
                    <div>
                        <label htmlFor="integrations.geminiApiKey" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Google Gemini API Key</label>
                        <input type="password" name="integrations.geminiApiKey" id="integrations.geminiApiKey" value={settings.integrations.geminiApiKey} onChange={handleInputChange} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">API Key for AI-powered features.</p>
                    </div>
                </div>
            );
            case 'License': return (
                 <div className="space-y-6">
                     <div>
                        <label htmlFor="license.defaultDurationDays" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Default License Duration (Days)</label>
                        <input type="number" name="license.defaultDurationDays" id="license.defaultDurationDays" value={settings.license.defaultDurationDays} onChange={handleInputChange} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">The default validity period for newly generated school licenses.</p>
                    </div>
                     <div>
                        <label htmlFor="license.prefix" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">License Key Prefix</label>
                        <input type="text" name="license.prefix" id="license.prefix" value={settings.license.prefix} onChange={handleInputChange} maxLength={5} className="w-full max-w-md bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500"/>
                        <p className="text-xs text-slate-500 mt-1">A short prefix (e.g., EDT) for all generated license keys.</p>
                    </div>
                </div>
            );
            default: return null;
        }
    }

    return (
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-md overflow-hidden flex flex-col md:flex-row min-h-[calc(100vh-12rem)]">
            <nav className="w-full md:w-64 p-4 border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-700 flex-shrink-0">
                <ul className="flex flex-row md:flex-col gap-1">
                    {tabs.map(tab => (
                        <li key={tab.name}>
                            <button
                                onClick={() => setActiveTab(tab.name)}
                                className={`w-full flex items-center gap-3 p-3 rounded-lg text-sm font-semibold transition-colors ${activeTab === tab.name ? 'bg-primary-100 dark:bg-primary-900/50 text-primary-600 dark:text-primary-300' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                            >
                                <tab.icon size={18} />
                                <span className="hidden sm:inline">{tab.name}</span>
                            </button>
                        </li>
                    ))}
                </ul>
            </nav>
            <div className="flex-1 p-6 sm:p-8">
                <h2 className="text-2xl font-bold text-slate-800 dark:text-slate-200 mb-6">{activeTab} Settings</h2>
                {renderContent()}
            </div>
            
            {hasChanges && (
                <div className="sticky bottom-0 w-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm p-4 border-t border-slate-200 dark:border-slate-700 flex justify-end items-center gap-4 mt-auto">
                    <p className="text-sm text-slate-600 dark:text-slate-300">You have unsaved changes.</p>
                    <button onClick={handleCancelChanges} className="flex items-center gap-2 px-4 py-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-600 font-semibold">
                       <XCircle size={16}/> Cancel
                    </button>
                    <button onClick={handleSaveChanges} className="flex items-center gap-2 bg-primary-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-primary-700 transition-colors shadow-sm">
                       <Save size={16}/> Save Changes
                    </button>
                </div>
            )}
        </div>
    );
};

export default SystemSettingsScreen;