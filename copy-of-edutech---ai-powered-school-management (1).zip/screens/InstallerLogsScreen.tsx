import React, { useState, useMemo, useEffect } from 'react';
import { LogEntry, LogLevel } from '../types';
import { FileTerminal, Search, Sigma, AlertCircle, CheckCircle, ShieldCheck, Eye } from 'lucide-react';
import LogDetailModal from '../components/modals/LogDetailModal';

const mockLogs: LogEntry[] = [
    { id: 'LOG-001', timestamp: '2024-05-21 14:30:15', level: 'SUCCESS', schoolName: 'King\'s College', event: 'License Activated', details: 'License key KCL-LGS-A1B2-C3D4 successfully validated and activated for King\'s College.' },
    { id: 'LOG-002', timestamp: '2024-05-21 10:05:22', level: 'INFO', schoolName: 'Queen\'s College', event: 'User Login', details: 'Admin user "T. O. Adeyemi" logged in successfully from IP 192.168.1.1.' },
    { id: 'LOG-003', timestamp: '2024-05-20 18:15:00', level: 'ERROR', schoolName: 'Barewa College', event: 'Database Connection Failed', details: 'Failed to connect to database: `mysql:host=localhost;dbname=edutech_barewa`. Reason: Access denied for user \'root\'@\'localhost\'.\n\nStack Trace:\n  at new PDO(...)\n  at DatabaseConnector->connect(...)\n  at Application->bootstrap(...)' },
    { id: 'LOG-004', timestamp: '2024-05-20 16:00:45', level: 'INFO', schoolName: 'Platform-wide', event: 'System Update Started', details: 'System update to version 2.1.0 initiated by Super Admin.' },
    { id: 'LOG-005', timestamp: '2024-05-20 16:05:10', level: 'SUCCESS', schoolName: 'Platform-wide', event: 'System Update Completed', details: 'System update to version 2.1.0 completed successfully.' },
    { id: 'LOG-006', timestamp: '2024-05-19 09:00:00', level: 'WARN', schoolName: 'Loyola Jesuit College', event: 'SMTP Mailer Misconfiguration', details: 'Attempted to send welcome email to new user, but SMTP server details are not configured. Email was not sent.' },
    { id: 'LOG-007', timestamp: '2024-05-18 11:45:30', level: 'INFO', schoolName: 'King\'s College', event: 'Data Exported', details: 'Admin user "Andrew Ali" exported student records for JSS1.' },
];

const StatCard = ({ title, value, icon }: { title: string, value: string, icon: React.ReactNode }) => (
    <div className="bg-white dark:bg-slate-800 p-5 rounded-xl shadow-md flex items-center gap-4">
        <div className="bg-primary-100 dark:bg-primary-900/50 text-primary-500 p-3 rounded-lg">
            {icon}
        </div>
        <div>
            <p className="text-sm font-medium text-slate-500 dark:text-slate-400">{title}</p>
            <p className="text-2xl font-bold text-slate-800 dark:text-slate-200">{value}</p>
        </div>
    </div>
);

const levelColors: Record<LogLevel, { text: string; bg: string }> = {
  INFO: { text: 'text-blue-800 dark:text-blue-300', bg: 'bg-blue-100 dark:bg-blue-900/50' },
  SUCCESS: { text: 'text-green-800 dark:text-green-300', bg: 'bg-green-100 dark:bg-green-900/50' },
  WARN: { text: 'text-yellow-800 dark:text-yellow-300', bg: 'bg-yellow-100 dark:bg-yellow-900/50' },
  ERROR: { text: 'text-red-800 dark:text-red-300', bg: 'bg-red-100 dark:bg-red-900/50' },
};

const ITEMS_PER_PAGE = 10;

const InstallerLogsScreen: React.FC = () => {
    const [logs, setLogs] = useState<LogEntry[]>(mockLogs);
    const [searchQuery, setSearchQuery] = useState('');
    const [levelFilter, setLevelFilter] = useState<LogLevel | 'All'>('All');
    const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
    const [selectedLog, setSelectedLog] = useState<LogEntry | null>(null);
    const [currentPage, setCurrentPage] = useState(1);

    const filteredLogs = useMemo(() => {
        return logs
          .filter(log => log.event.toLowerCase().includes(searchQuery.toLowerCase()) || log.schoolName.toLowerCase().includes(searchQuery.toLowerCase()))
          .filter(log => levelFilter === 'All' || log.level === levelFilter);
    }, [logs, searchQuery, levelFilter]);

    const paginatedLogs = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return filteredLogs.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredLogs, currentPage]);
    
    const totalPages = Math.ceil(filteredLogs.length / ITEMS_PER_PAGE);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, levelFilter]);

    const handleOpenDetailModal = (log: LogEntry) => {
        setSelectedLog(log);
        setIsDetailModalOpen(true);
    };

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Total Log Entries" value={String(logs.length)} icon={<Sigma size={24}/>} />
                <StatCard title="Errors (Last 24h)" value="1" icon={<AlertCircle size={24} className="text-red-500"/>} />
                <StatCard title="Successful Activations" value="2" icon={<ShieldCheck size={24} className="text-green-500"/>} />
                <StatCard title="Updates Performed" value="1" icon={<CheckCircle size={24} className="text-blue-500"/>} />
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-2xl shadow-md">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
                    <div className="relative w-full md:flex-1">
                      <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input type="text" placeholder="Search by school or event..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="w-full bg-slate-100 dark:bg-slate-700 rounded-md py-2.5 pl-10 pr-4 focus:ring-2 focus:ring-primary-500 border-transparent" />
                    </div>
                    <div className="flex items-center gap-2 w-full md:w-auto">
                      <select value={levelFilter} onChange={e => setLevelFilter(e.target.value as LogLevel | 'All')} className="w-full md:w-auto bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500">
                        <option value="All">All Levels</option>
                        <option value="INFO">Info</option>
                        <option value="WARN">Warning</option>
                        <option value="ERROR">Error</option>
                        <option value="SUCCESS">Success</option>
                      </select>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-slate-500 dark:text-slate-400 responsive-table">
                        <thead className="text-xs text-slate-700 uppercase bg-slate-50 dark:bg-slate-700 dark:text-slate-300">
                            <tr>
                                <th scope="col" className="px-6 py-3">Timestamp</th>
                                <th scope="col" className="px-6 py-3">Level</th>
                                <th scope="col" className="px-6 py-3">School</th>
                                <th scope="col" className="px-6 py-3">Event</th>
                                <th scope="col" className="px-6 py-3"></th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedLogs.map((log) => (
                                <tr key={log.id} className="bg-white dark:bg-slate-800 border-b dark:border-slate-700">
                                    <td data-label="Timestamp" className="px-6 py-4 font-mono text-slate-600 dark:text-slate-400">{log.timestamp}</td>
                                    <td data-label="Level" className="px-6 py-4">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${levelColors[log.level].bg} ${levelColors[log.level].text}`}>
                                            {log.level}
                                        </span>
                                    </td>
                                    <td data-label="School" className="px-6 py-4 font-medium text-slate-800 dark:text-slate-200">{log.schoolName}</td>
                                    <td data-label="Event" className="px-6 py-4">{log.event}</td>
                                    <td data-label="Actions" className="px-6 py-4 text-center">
                                        <button onClick={() => handleOpenDetailModal(log)} className="flex items-center gap-1 text-primary-600 dark:text-primary-400 hover:underline text-xs">
                                            <Eye size={14} /> View Details
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {filteredLogs.length > 0 ? (
                    <div className="flex flex-col sm:flex-row items-center justify-between pt-4 gap-4">
                        <span className="text-sm text-slate-500">
                            Showing {paginatedLogs.length} of {filteredLogs.length} log entries
                        </span>
                        <div className="flex gap-2">
                             <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Previous</button>
                             <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-3 py-1 text-sm rounded-md bg-slate-200 dark:bg-slate-700 disabled:opacity-50">Next</button>
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-10 text-slate-500">
                      <FileTerminal size={48} className="mx-auto text-slate-400 mb-4" />
                      <h3 className="text-lg font-semibold">No Logs Found</h3>
                      <p>No log entries match your current search and filter criteria.</p>
                    </div>
                )}
            </div>
            
            <LogDetailModal
                isOpen={isDetailModalOpen}
                onClose={() => setIsDetailModalOpen(false)}
                log={selectedLog}
            />
        </div>
    );
};

export default InstallerLogsScreen;
