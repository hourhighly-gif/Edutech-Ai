import React from 'react';
import { LogEntry, LogLevel } from '../../types';
import { X, FileTerminal } from 'lucide-react';

interface LogDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  log: LogEntry | null;
}

const levelColors: Record<LogLevel, { text: string; bg: string, border: string }> = {
  INFO: { text: 'text-blue-800 dark:text-blue-300', bg: 'bg-blue-100 dark:bg-blue-900/50', border: 'border-blue-500' },
  SUCCESS: { text: 'text-green-800 dark:text-green-300', bg: 'bg-green-100 dark:bg-green-900/50', border: 'border-green-500' },
  WARN: { text: 'text-yellow-800 dark:text-yellow-300', bg: 'bg-yellow-100 dark:bg-yellow-900/50', border: 'border-yellow-500' },
  ERROR: { text: 'text-red-800 dark:text-red-300', bg: 'bg-red-100 dark:bg-red-900/50', border: 'border-red-500' },
};

const LogDetailModal: React.FC<LogDetailModalProps> = ({ isOpen, onClose, log }) => {
  if (!isOpen || !log) return null;

  const color = levelColors[log.level];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className={`flex items-center justify-between p-6 border-b ${color.border} border-opacity-30`}>
          <div className="flex items-center gap-3">
            <FileTerminal className={color.text} size={24}/>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">Log Details</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700">
            <X size={20} />
          </button>
        </div>
        
        <div className="overflow-y-auto p-6 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                <div>
                    <p className="font-semibold text-slate-600 dark:text-slate-400">Timestamp</p>
                    <p className="font-mono text-slate-800 dark:text-slate-200">{log.timestamp}</p>
                </div>
                <div>
                    <p className="font-semibold text-slate-600 dark:text-slate-400">Level</p>
                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${color.bg} ${color.text}`}>
                        {log.level}
                    </span>
                </div>
                 <div>
                    <p className="font-semibold text-slate-600 dark:text-slate-400">School</p>
                    <p className="text-slate-800 dark:text-slate-200">{log.schoolName}</p>
                </div>
            </div>
             <div>
                <p className="font-semibold text-slate-600 dark:text-slate-400">Event</p>
                <p className="text-slate-800 dark:text-slate-200 text-base font-medium">{log.event}</p>
            </div>
             <div>
                <p className="font-semibold text-slate-600 dark:text-slate-400 mb-1">Full Details</p>
                <pre className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap break-words font-mono">
                    <code>{log.details}</code>
                </pre>
            </div>
        </div>
        
        <div className="flex items-center justify-end p-6 border-t border-slate-200 dark:border-slate-700 mt-auto">
          <button onClick={onClose} className="px-6 py-2.5 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700">
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default LogDetailModal;
