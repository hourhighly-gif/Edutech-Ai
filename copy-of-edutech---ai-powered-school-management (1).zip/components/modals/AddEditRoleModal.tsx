import React, { useState, useEffect } from 'react';
import { Role } from '../../types';
import { X, Shield } from 'lucide-react';

interface AddEditRoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (role: Pick<Role, 'name'|'description'>) => void;
  role?: Role;
}

const AddEditRoleModal: React.FC<AddEditRoleModalProps> = ({ isOpen, onClose, onSave, role }) => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (isOpen) {
      if (role) {
        setName(role.name);
        setDescription(role.description);
      } else {
        setName('');
        setDescription('');
      }
    }
  }, [role, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ name, description });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-700">
          <div className="flex items-center gap-3">
            <Shield className="text-primary-500" size={24}/>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-200">{role ? 'Edit Role' : 'Add New Role'}</h2>
          </div>
          <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-slate-100 dark:hover:bg-slate-700">
            <X size={20} />
          </button>
        </div>
        
        <div className="overflow-y-auto p-6 space-y-4">
           <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Role Name</label>
              <input type="text" name="name" id="name" value={name} onChange={(e) => setName(e.target.value)} required className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500" />
          </div>
           <div>
              <label htmlFor="description" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
              <textarea name="description" id="description" value={description} onChange={(e) => setDescription(e.target.value)} required rows={3} className="w-full bg-slate-100 dark:bg-slate-700 border-transparent rounded-md p-2.5 focus:ring-2 focus:ring-primary-500" />
          </div>
        </div>
        
        <div className="flex items-center justify-end p-6 border-t border-slate-200 dark:border-slate-700 mt-auto">
          <button type="button" onClick={onClose} className="px-6 py-2.5 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700">
            Cancel
          </button>
          <button type="submit" className="px-6 py-2.5 bg-primary-600 text-white font-semibold rounded-lg hover:bg-primary-700 ml-3">
            Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddEditRoleModal;