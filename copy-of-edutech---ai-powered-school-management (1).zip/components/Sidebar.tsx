import React from 'react';
import { PageName } from '../types';
import {
  LayoutDashboard, Building2, Users, MessageSquare, Shield,
  FileTerminal, Settings, HelpCircle, X, GraduationCap
} from 'lucide-react';

interface SidebarProps {
  activePage: PageName;
  onNavigate: (page: PageName) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const navItems: { name: PageName; icon: React.ElementType }[] = [
  { name: 'Dashboard', icon: LayoutDashboard },
  { name: 'Schools Management', icon: Building2 },
  { name: 'Users Management', icon: Users },
  { name: 'Messaging & Notifications', icon: MessageSquare },
  { name: 'Roles & Permissions Management', icon: Shield },
  { name: 'Installer Logs Management', icon: FileTerminal },
  { name: 'System Settings Management', icon: Settings },
  { name: 'Help & Documentation Center', icon: HelpCircle },
];

const Sidebar: React.FC<SidebarProps> = ({ activePage, onNavigate, isOpen, setIsOpen }) => {
  const handleNavigation = (page: PageName) => {
    onNavigate(page);
    if (isOpen) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && <div onClick={() => setIsOpen(false)} className="fixed inset-0 bg-black opacity-50 z-40 lg:hidden"></div>}

      <aside className={`fixed lg:relative inset-y-0 left-0 bg-white dark:bg-slate-800 w-64 transform ${isOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform duration-300 ease-in-out z-50 flex flex-col shadow-lg lg:shadow-none`}>
        <div className="flex items-center justify-between h-16 px-6 border-b border-slate-200 dark:border-slate-700 flex-shrink-0">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-8 w-8 text-primary-500" />
            <span className="text-xl font-bold text-slate-800 dark:text-slate-200">EduTech</span>
          </div>
          <button onClick={() => setIsOpen(false)} className="lg:hidden text-slate-500 hover:text-slate-700">
            <X size={24} />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {navItems.map((item) => (
            <button
              key={item.name}
              onClick={() => handleNavigation(item.name)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-md text-sm font-medium transition-colors ${
                activePage === item.name
                  ? 'bg-primary-100 dark:bg-primary-900/50 text-primary-600 dark:text-primary-300'
                  : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
              }`}
            >
              <item.icon className="h-5 w-5" />
              <span>{item.name}</span>
            </button>
          ))}
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;