export type PageName =
  | 'Dashboard'
  | 'Schools Management'
  | 'Users Management'
  | 'Messaging & Notifications'
  | 'Roles & Permissions Management'
  | 'Installer Logs Management'
  | 'System Settings Management'
  | 'Help & Documentation Center';

export interface Question {
  questionText: string;
  options: string[];
  correctAnswerIndex: number;
}

export type SchoolStatus = 'Active' | 'Inactive' | 'Pending Activation';

export interface School {
  id: string;
  name: string;
  motto?: string;
  principal: string;
  email: string;
  phone: string;
  address: string;
  lga: string;
  state: NigerianState;
  status: SchoolStatus;
  licenseKey: string;
  studentCount: number;
  teacherCount: number;
  logoUrl?: string;
}

export const NigerianStates = [
  "Abia", "Adamawa", "Akwa Ibom", "Anambra", "Bauchi", "Bayelsa", "Benue", "Borno", 
  "Cross River", "Delta", "Ebonyi", "Edo", "Ekiti", "Enugu", "FCT - Abuja", "Gombe", 
  "Imo", "Jigawa", "Kaduna", "Kano", "Katsina", "Kebbi", "Kogi", "Kwara", "Lagos", 
  "Nasarawa", "Niger", "Ogun", "Ondo", "Osun", "Oyo", "Plateau", "Rivers", "Sokoto", 
  "Taraba", "Yobe", "Zamfara"
] as const;

export type NigerianState = typeof NigerianStates[number];

export type UserRole = 'Super Admin' | 'School Admin';
export type UserStatus = 'Active' | 'Inactive';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  schoolAffiliation: string;
  dateAdded: string;
  status: UserStatus;
  avatar: string;
}

export interface Permission {
  id: string;
  name: string;
  description: string;
}

export interface PermissionModule {
  id: string;
  name: string;
  permissions: Permission[];
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: string[]; // Array of permission IDs
  isCoreRole?: boolean; // To protect Super Admin, etc.
}

export type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';

export interface LogEntry {
  id: string;
  timestamp: string;
  level: LogLevel;
  schoolName: string;
  event: string;
  details: string;
}

export interface SystemSettings {
  general: {
    platformName: string;
    platformLogo: string;
    academicYearStart: string;
    academicYearEnd: string;
  };
  appearance: {
    theme: 'light' | 'dark' | 'system';
    primaryColor: string;
  };
  notifications: {
    senderName: string;
    senderEmail: string;
  };
  integrations: {
    paymentGatewayKey: string;
    geminiApiKey: string;
  };
  license: {
    defaultDurationDays: number;
    prefix: string;
  };
}