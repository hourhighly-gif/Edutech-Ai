import { GoogleGenAI, Type } from "@google/genai";
import { Question } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const questionSchema = {
  type: Type.OBJECT,
  properties: {
    questions: {
      type: Type.ARRAY,
      description: "An array of multiple-choice questions.",
      items: {
        type: Type.OBJECT,
        properties: {
          questionText: {
            type: Type.STRING,
            description: "The text of the question.",
          },
          options: {
            type: Type.ARRAY,
            description: "An array of 4 possible answers.",
            items: { type: Type.STRING },
          },
          correctAnswerIndex: {
            type: Type.INTEGER,
            description: "The 0-based index of the correct answer in the options array.",
          },
        },
        required: ["questionText", "options", "correctAnswerIndex"],
      },
    },
  },
  required: ["questions"],
};

export const generateTestQuestions = async (topic: string, numQuestions: number, difficulty: string): Promise<Question[]> => {
  try {
    const prompt = `Generate ${numQuestions} multiple-choice questions for a Nigerian student at a '${difficulty}' level, based on the Nigerian educational curriculum for the topic "${topic}". Each question must have exactly 4 options. Ensure the questions and options are culturally and contextually relevant for Nigeria.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: questionSchema,
        temperature: 0.7,
      },
    });

    const jsonString = response.text;
    const parsedJson = JSON.parse(jsonString);
    
    if (parsedJson && parsedJson.questions) {
       // Validate that each question has 4 options
       const validQuestions = parsedJson.questions.filter((q: any) => Array.isArray(q.options) && q.options.length === 4);
       if(validQuestions.length !== parsedJson.questions.length) {
         console.warn("Some generated questions did not have 4 options and were filtered out.");
       }
       return validQuestions as Question[];
    }
    return [];

  } catch (error) {
    console.error("Error generating test questions:", error);
    throw new Error("Failed to generate questions. Please check the topic and try again.");
  }
};
